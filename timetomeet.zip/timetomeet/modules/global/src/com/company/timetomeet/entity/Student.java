package com.company.timetomeet.entity;

import com.haulmont.cuba.core.entity.StandardEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name = "TIMETOMEET_STUDENT")
@Entity(name = "timetomeet_Student")
public class Student extends StandardEntity {
    private static final long serialVersionUID = -4955457954903036030L;

    @Column(name = "STUDENT_ID")
    private String student_id;

    @Column(name = "LAST_NAME")
    private String last_name;

    @Column(name = "FIRST_NAME")
    private String first_name;

    @Column(name = "SUBJECT")
    private String subject;

    @Column(name = "EMAIL")
    private String email;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getStudent_id() {
        return student_id;
    }

    public void setStudent_id(String student_id) {
        this.student_id = student_id;
    }
}