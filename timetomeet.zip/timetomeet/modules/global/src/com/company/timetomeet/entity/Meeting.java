package com.company.timetomeet.entity;

import com.haulmont.cuba.core.entity.StandardEntity;

import javax.persistence.*;
import java.util.Date;

@Table(name = "TIMETOMEET_MEETING")
@Entity(name = "timetomeet_Meeting")
public class Meeting extends StandardEntity {
    private static final long serialVersionUID = -3834239093344773201L;

    @Column(name = "MEETING_ID")
    private String meeting_id;

    @Temporal(TemporalType.DATE)
    @Column(name = "DATE_")
    private Date date;

    @Temporal(TemporalType.TIME)
    @Column(name = "TIME_")
    private Date time;

    @Column(name = "PLACE")
    private String place;

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getMeeting_id() {
        return meeting_id;
    }

    public void setMeeting_id(String meeting_id) {
        this.meeting_id = meeting_id;
    }
}