alter table TIMETOMEET_MEETING add column TEACHER varchar(255) ;
