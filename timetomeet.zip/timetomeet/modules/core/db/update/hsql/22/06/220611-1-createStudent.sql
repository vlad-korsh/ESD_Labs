create table TIMETOMEET_STUDENT (
    ID varchar(36) not null,
    VERSION integer not null,
    CREATE_TS timestamp,
    CREATED_BY varchar(50),
    UPDATE_TS timestamp,
    UPDATED_BY varchar(50),
    DELETE_TS timestamp,
    DELETED_BY varchar(50),
    --
    STUDENT_ID varchar(255),
    LAST_NAME varchar(255),
    FIRST_NAME varchar(255),
    SUBJECT varchar(255),
    EMAIL varchar(255),
    --
    primary key (ID)
);