package com.company.timetomeet.web.screens.meeting;

import com.haulmont.cuba.gui.screen.*;
import com.company.timetomeet.entity.Meeting;

@UiController("timetomeet_Meeting.browse")
@UiDescriptor("meeting-browse.xml")
@LookupComponent("meetingsTable")
@LoadDataBeforeShow
public class MeetingBrowse extends StandardLookup<Meeting> {
}