package com.company.timetomeet.web.screens.teacher;

import com.haulmont.cuba.gui.screen.*;
import com.company.timetomeet.entity.Teacher;

@UiController("timetomeet_Teacher.edit")
@UiDescriptor("teacher-edit.xml")
@EditedEntityContainer("teacherDc")
@LoadDataBeforeShow
public class TeacherEdit extends StandardEditor<Teacher> {
}