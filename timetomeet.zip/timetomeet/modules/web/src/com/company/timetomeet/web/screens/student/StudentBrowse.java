package com.company.timetomeet.web.screens.student;

import com.haulmont.cuba.gui.screen.*;
import com.company.timetomeet.entity.Student;

@UiController("timetomeet_Student.browse")
@UiDescriptor("student-browse.xml")
@LookupComponent("studentsTable")
@LoadDataBeforeShow
public class StudentBrowse extends StandardLookup<Student> {
}