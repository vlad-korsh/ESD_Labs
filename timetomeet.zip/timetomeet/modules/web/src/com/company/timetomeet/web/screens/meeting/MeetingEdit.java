package com.company.timetomeet.web.screens.meeting;

import com.haulmont.cuba.gui.screen.*;
import com.company.timetomeet.entity.Meeting;

@UiController("timetomeet_Meeting.edit")
@UiDescriptor("meeting-edit.xml")
@EditedEntityContainer("meetingDc")
@LoadDataBeforeShow
public class MeetingEdit extends StandardEditor<Meeting> {
}